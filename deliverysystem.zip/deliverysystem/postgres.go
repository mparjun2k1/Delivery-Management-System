package database

import (
    "database/sql"
    _ "github.com/lib/pq"
)

func ConnectPostgres() (*sql.DB, error) {
    return sql.Open("postgres", "user=postgres password=postsql dbname=deliverydb sslmode=disable")
}
